export function log(mensagem) {
    console.log(process.env.MINHA_VAR);
    console.log(mensagem);
}